<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<script type="text/javascript" src="../scripts/mootools-core-1.4.5-full-nocompat.js"></script>
<script type="text/javascript" src="../scripts/mootools-more-1.4.0.1.js"></script>

    
<style type="text/css">

	/* hide from ie on mac \*/
	html {
		height: 100%;
		overflow: hidden;
	}

	#flashcontent {
		height: 100%;
		min-height: 100%;		
	}
	/* end hide */

	body {
		height: 100%;
		margin: 0;
		padding: 0;
	}

</style>

</head>
<body>
<iframe width="100%" height="100%" src="http://www.youtube.com/embed/dP15zlyra3c?html5=1"></iframe>

</body>
</html>

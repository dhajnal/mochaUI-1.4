A MooTools UI (User Interface) Library

2013-06-24
Added CSS3 styled radio an checkbox CSS files.
- Body mass index form (BMI) with new CSS3 radio buttons ,set and get values
- formtest.php with radio ,checkbox, calendar ..... with HTML5 validation test.
- call same form in Window or in a main Panel


Upgraded from Mootools 1.2 to 1.4.5 no compat version!

Release Version # is 1.4.0

This is fork from Gregory Houston MochaUI.

For details see pages/notes.html for changes and description.

See demo at mochaui.domenacom.hr

darko.hajnal@domenacom.hr

New themes CSS matija.benke@domenacom.hr

